<?php include_once('includes/header.php'); ?>
    <!-- page name -->
    <title>Best Digital Marketing Company In Kochi | Kerala</title>
    <meta name="description" content="" />
    
<?php include_once('includes/header1.php'); ?>
<!-- menu -->
        <div class="mil-menu-frame">
            <!-- frame clone -->
            <div class="mil-frame-top">
                <a href="index.php" class="mil-logo"><img src="img/nav-icon.png" alt=""></a>
                <div class="mil-menu-btn">
                    <span></span>
                </div>
            </div>
            <!-- frame clone end -->
            <div class="container">
                <div class="mil-menu-content">
                    <div class="row">
                        <div class="col-xl-5">

                            <nav class="mil-main-menu" id="swupMenu">
                                <ul>
                                    <li class="mil-has-children"><a href="index.php">Home</a></li>
                                    <li class="mil-has-children"><a href="about.php">About Us</a></li>
                                    <li class="mil-has-children"><a href="services.php">Services</a></li>
                                    <li class="mil-has-children"><a href="portfolio.php">Portfolio</a></li>
                                    <li class="mil-has-children"><a href="blog.php">Blog</a></li>
                                    <li class="mil-has-children"><a href="contact.php">Contact Us</a></li>
                                    
                                </ul>
                            </nav>

                        </div>
                       <!--  <div class="col-xl-7">

                            <div class="mil-menu-right-frame">
                                <div class="mil-animation-in">
                                    <div class="mil-animation-frame">
                                        <div class="mil-animation mil-position-1 mil-scale" data-value-1="2" data-value-2="2"></div>
                                    </div>
                                </div>
                                <div class="mil-menu-right">
                                    <div class="row">
                                        <div class="col-lg-8 mil-mb-60">

                                            <h6 class="mil-muted mil-mb-30">Projects</h6>

                                            <ul class="mil-menu-list">
                                                <li><a href="project-1.html" class="mil-light-soft">Interior design studio</a></li>
                                                <li><a href="project-2.html" class="mil-light-soft">Home Security Camera</a></li>
                                                <li><a href="project-3.html" class="mil-light-soft">Kemia Honest Skincare</a></li>
                                                <li><a href="project-4.html" class="mil-light-soft">Cascade of Lava</a></li>
                                                <li><a href="project-5.html" class="mil-light-soft">Air Pro by Molekule</a></li>
                                                <li><a href="project-6.html" class="mil-light-soft">Tony's Chocolonely</a></li>
                                            </ul>

                                        </div>
                                        <div class="col-lg-4 mil-mb-60">

                                            <h6 class="mil-muted mil-mb-30">Useful links</h6>

                                            <ul class="mil-menu-list">
                                                <li><a href="#." class="mil-light-soft">Privacy Policy</a></li>
                                                <li><a href="#." class="mil-light-soft">Terms and conditions</a></li>
                                                <li><a href="#." class="mil-light-soft">Cookie Policy</a></li>
                                                <li><a href="#." class="mil-light-soft">Careers</a></li>
                                            </ul>

                                        </div>
                                    </div>
                                    <div class="mil-divider mil-mb-60"></div>
                                    <div class="row justify-content-between">

                                        <div class="col-lg-4 mil-mb-60">

                                            <h6 class="mil-muted mil-mb-30">Canada</h6>

                                            <p class="mil-light-soft mil-up">71 South Los Carneros Road, California <span class="mil-no-wrap">+51 174 705 812</span></p>

                                        </div>
                                        <div class="col-lg-4 mil-mb-60">

                                            <h6 class="mil-muted mil-mb-30">Germany</h6>

                                            <p class="mil-light-soft">Leehove 40, 2678 MC De Lier, Netherlands <span class="mil-no-wrap">+31 174 705 811</span></p>

                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div> -->
                    </div>
                </div>
            </div>
        </div>
        <!-- menu -->
        <!-- curtain -->
        <div class="mil-curtain"></div>
        <!-- curtain end -->

        <!-- frame -->
        <div class="mil-frame">
            <div class="mil-frame-top">
                <a href="index.php" class="mil-logo"><img src="img/nav-icon.png" alt=""></a>
                <div class="mil-menu-btn">
                    <span></span>
                </div>
            </div>
            <div class="mil-frame-bottom">
                <div class="mil-current-page">Refund and Cancellation</div>
                <div class="mil-back-to-top">
                    <a href="#top" class="mil-link mil-dark mil-arrow-place">
                        <span>Back to top</span>
                    </a>
                </div>
            </div>
        </div>
        <!-- frame end -->

        <!-- content -->
        <div class="mil-content">
            <div id="swupMain" class="mil-main-transition">

                <!-- banner -->
                <div class="mil-inner-banner">
                    <div class="mil-banner-content mil-center mil-up">
                        <div class="container">
                            <ul class="mil-breadcrumbs mil-center mil-mb-60">
                                <li><a href="index.php">Home</a></li>
                                <li><a href="">Refund and Cancellation</a></li>
                            </ul>
                            <h2>Refund and Cancellation</h2>
                        </div>
                    </div>
                </div>
                <!-- banner end -->

                <!-- publication -->
                <section id="blog">
                    <div class="container mil-p-120-90">
                        <div class="row justify-content-center">
                            <div class="col-lg-8">

                                <p class="mil-up mil-mb-60">We,Yepman International, are  committed to providing each customer with exceptional service.</p>

                                <p class="mil-up mil-mb-60">The customer reserves all the right to cancel its Digital Marketing services with our company at any time with at least one week prior notice in writing. We will cancel the services within one week time from the date of receipt of the customer email. Upon cancellation, we will refund the excess amount, if any, after deducting the service charges/ad spends or any other actual charges incurred to us, within 14 days from the date of cancellation.</p>
                                <p class="mil-up mil-mb-60">We will not refund any amount which is already incurred to company or already paid to any third party vendors to the customer under any circumstances .</p>
                                <p class="mil-up mil-mb-60">If you have technical issues with the product or you can’t download the files contact us and we will help you as soon as possible.</p>
                                <p class="mil-up mil-mb-60">If you are not completely satisfied with our services, you may send us an email to sales@atbott.com  or call us +91-7902373354 we will reply with in 12-24 hours</p>
                                <p class="mil-up mil-mb-60">we are not liable in any case if you don’t know how to use the product we can help you if you don’t know the small technical things.</p>
                                <p class="mil-up mil-mb-60">Once you send an email, our team will get in touch to know the exact issue or problem for your dissatisfaction & will try to resolve your problem & query. If we are not able to solve it, only then we shall issue your refund.</p>
                                <p class="mil-up mil-mb-60"><b>Important Note:</b> Refunds are not possible in the case where you make a mistake while filling up your name & email for the payment of any course or if you make duplicate purchases or purchase by mistake. Refunds are not possible if you don’t understand English properly & have purchased our courses which is in English. Refunds are not possible if you think that you were suppose to get any upsell for free (just because of your non-understanding nature in the marketing world). We don’t offer refunds for any of those above cases.</p>




                            </div>
                        </div>
                    </div>
                </section>
                <!-- publication end -->


                <?php include_once('includes/footer.php'); ?>