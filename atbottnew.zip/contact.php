<?php include_once('includes/header.php'); ?>
    <!-- page name -->
    <title>Best Digital Marketing Company In Kochi | Kerala</title>
    <meta name="description" content="" />
    
<?php include_once('includes/header1.php'); ?>

        <!-- menu -->
        <div class="mil-menu-frame">
            <!-- frame clone -->
            <div class="mil-frame-top">
                <a href="index.php" class="mil-logo"><img src="img/nav-icon.png" alt=""></a>
                <div class="mil-menu-btn">
                    <span></span>
                </div>
            </div>
            <!-- frame clone end -->
            <div class="container">
                <div class="mil-menu-content">
                    <div class="row">
                        <div class="col-xl-5">

                            <nav class="mil-main-menu" id="swupMenu">
                                <ul>
                                    <li class="mil-has-children"><a href="index.php">Home</a></li>
                                    <li class="mil-has-children"><a href="about.php">About Us</a></li>
                                    <li class="mil-has-children"><a href="services.php">Services</a></li>
                                    <li class="mil-has-children"><a href="portfolio.php">Portfolio</a></li>
                                    <li class="mil-has-children"><a href="blog.php">Blog</a></li>
                                    <li class="mil-has-children mil-active"><a href="contact.php">Contact Us</a></li>                            
                                </ul>
                            </nav>

                        </div>
                        <!-- <div class="col-xl-7">

                            <div class="mil-menu-right-frame">
                                <div class="mil-animation-in">
                                    <div class="mil-animation-frame">
                                        <div class="mil-animation mil-position-1 mil-scale" data-value-1="2" data-value-2="2"></div>
                                    </div>
                                </div>
                                <div class="mil-menu-right">
                                    <div class="row">
                                        <div class="col-lg-8 mil-mb-60">

                                            <h6 class="mil-muted mil-mb-30">Projects</h6>

                                            <ul class="mil-menu-list">
                                                <li><a href="project-1.html" class="mil-light-soft">Interior design studio</a></li>
                                                <li><a href="project-2.html" class="mil-light-soft">Home Security Camera</a></li>
                                                <li><a href="project-3.html" class="mil-light-soft">Kemia Honest Skincare</a></li>
                                                <li><a href="project-4.html" class="mil-light-soft">Cascade of Lava</a></li>
                                                <li><a href="project-5.html" class="mil-light-soft">Air Pro by Molekule</a></li>
                                                <li><a href="project-6.html" class="mil-light-soft">Tony's Chocolonely</a></li>
                                            </ul>

                                        </div>
                                        <div class="col-lg-4 mil-mb-60">

                                            <h6 class="mil-muted mil-mb-30">Useful links</h6>

                                            <ul class="mil-menu-list">
                                                <li><a href="#." class="mil-light-soft">Privacy Policy</a></li>
                                                <li><a href="#." class="mil-light-soft">Terms and conditions</a></li>
                                                <li><a href="#." class="mil-light-soft">Cookie Policy</a></li>
                                                <li><a href="#." class="mil-light-soft">Careers</a></li>
                                            </ul>

                                        </div>
                                    </div>
                                    <div class="mil-divider mil-mb-60"></div>
                                    <div class="row justify-content-between">

                                        <div class="col-lg-4 mil-mb-60">

                                            <h6 class="mil-muted mil-mb-30">Canada</h6>

                                            <p class="mil-light-soft mil-up">71 South Los Carneros Road, California <span class="mil-no-wrap">+51 174 705 812</span></p>

                                        </div>
                                        <div class="col-lg-4 mil-mb-60">

                                            <h6 class="mil-muted mil-mb-30">Germany</h6>

                                            <p class="mil-light-soft">Leehove 40, 2678 MC De Lier, Netherlands <span class="mil-no-wrap">+31 174 705 811</span></p>

                                        </div>
                                    </div>
                                </div>
                            </div>

                        </div> -->
                    </div>
                </div>
            </div>
        </div>
        <!-- menu -->

        <!-- curtain -->
        <div class="mil-curtain"></div>
        <!-- curtain end -->

        <!-- frame -->
        <div class="mil-frame">
            <div class="mil-frame-top">
                <a href="home-1.html" class="mil-logo">A.</a>
                <div class="mil-menu-btn">
                    <span></span>
                </div>
            </div>
            <div class="mil-frame-bottom">
                <div class="mil-current-page"></div>
                <div class="mil-back-to-top">
                    <a href="#top" class="mil-link mil-dark mil-arrow-place">
                        <span>Back to top</span>
                    </a>
                </div>
            </div>
        </div>
        <!-- frame end -->

        <!-- content -->
        <div class="mil-content">
            <div id="swupMain" class="mil-main-transition">

                <!-- banner -->
                <div class="mil-inner-banner mil-p-0-120">
                    <div class="mil-banner-content mil-center mil-up">
                        <div class="container">
                            <ul class="mil-breadcrumbs mil-center mil-mb-60">
                                <li><a href="index.php">Home</a></li>
                                <li><a href="contact.php">Contact Us</a></li>
                            </ul>
                            <h1 class="mil-mb-60">Get in touch!</h1>
                            <a href="#contact" class="mil-link mil-dark mil-arrow-place mil-down-arrow">
                                <span>Send message</span>
                            </a>
                        </div>
                    </div>
                </div>
                <!-- banner end -->

                <!-- map -->
                <div class="mil-map-frame mil-up">
                    <div class="mil-map">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3929.2109352004013!2d76.29388757503115!3d9.999427690105948!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3b080de3411365fd%3A0x8a8e28b4a7ec7e26!2sAtbott%20Solutions%20-%20Digital%20Marketing%20Company%20in%20Kerala%20%7C%20Kochi!5e0!3m2!1sen!2sin!4v1716624295467!5m2!1sen!2sin" width="600" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
                <!-- map end -->

                <!-- contact form -->
                <section id="contact">
                    <div class="container mil-p-120-90">
                        <h3 class="mil-center mil-up mil-mb-120">Let's <span class="mil-thin">Talk</span></h3>
                        <form class="row align-items-center">
                            <div class="col-lg-12 mil-up">
                                <input type="text" placeholder="What's your name">
                            </div>
                            <div class="col-lg-6 mil-up">
                                <input type="email" placeholder="Your Email">
                            </div>
                            <div class="col-lg-6 mil-up">
                                <input type="text" placeholder="Phone Number">
                            </div>
                            <div class="col-lg-12 mil-up">
                                <textarea placeholder="Tell us about our project"></textarea>
                            </div>
                            <div class="col-lg-8">
                               
                            </div>
                            <div class="col-lg-4">
                                <div class="mil-adaptive-right mil-up mil-mb-30">
                                    <button type="submit" class="mil-button mil-arrow-place">
                                        <span>Send message</span>
                                    </button>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
                <!-- contact form end -->

<?php include_once('includes/footer.php'); ?>